﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PS3Lib;

namespace Cryptix_RTM_Tool
{
    public partial class CryptixRTM : Form
    {
        public CryptixRTM()
        {
            InitializeComponent();
        }
        public static PS3API PS3 = new PS3API();

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {

                PS3.AttachProcess();

                MessageBox.Show("Successfully Attached to GTA5!", "Attached", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

            catch
            {

                MessageBox.Show("Failed to Attach", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                PS3.ConnectTarget(0);

                MessageBox.Show("Successfully Connected to PS3!", "Connected😄", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

            catch
            {

                MessageBox.Show("Failed to Connect to PS3 :(", "Failed😑", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            PS3.ChangeAPI(SelectAPI.TargetManager);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            PS3.ChangeAPI(SelectAPI.ControlConsole);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            byte[] Godmodeon = new byte[] { 0x38, 0x60, 0x7f, 0xff, 0xb0, 0x7f, 0x00, 0xb4 };

            PS3.SetMemory(0x118A548, Godmodeon);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            byte[] Godmodeoff = new byte[] { 0xFC, 0x01, 0x10, 0x00, 0x41, 0x80, 0x01, 0x14 };

            PS3.SetMemory(0x118A548, Godmodeoff);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            byte[] NeverWanted = new byte[] { 0x39, 0x60, 0x00, 0x00 };

            PS3.SetMemory(0x1041FE0, NeverWanted);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            byte[] DeveloperMode = new byte[] { 0x01 };

            PS3.SetMemory(0x133FCD3, DeveloperMode);
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            {
                {
                    Protections protectionsForm = new Protections();
                    protectionsForm.Show();
                }
            }

        }



        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            byte[] OldDevModeOn = new byte[] { 0x01 };
            PS3.SetMemory(0x3E302B, OldDevModeOn);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            byte[] OldDevModeOff = new byte[] { 0x00 };
            PS3.SetMemory(0x3E302B, OldDevModeOff);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            byte[] RockstarDevModeOn = new byte[] { 0x01 };
            PS3.SetMemory(0x003E30B4, RockstarDevModeOn);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            byte[] RockstarDevModeOff = new byte[] { 0x00 };
            PS3.SetMemory(0x003E30B4, RockstarDevModeOff);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This will unban you and maybe even stop you from being banned again!", "Antiban Notice👨🏾‍💻", MessageBoxButtons.OK, MessageBoxIcon.Information);
            // NETWORK::_IS_SOCIALCLUB_BANNED bypass
            byte[] SocialclubBypass = new byte[] { 0x38, 0x60, 0x00, 0x01, 0x4E, 0x80, 0x00, 0x20 };
            PS3.SetMemory(0x003F3964, SocialclubBypass);

            // NETWORK::_IS_ROCKSTAR_BANNED bypass
            byte[] RockstarBypass = new byte[] { 0x38, 0x60, 0x00, 0x00, 0x4E, 0x80, 0x00, 0x20 };
            PS3.SetMemory(0x003F3910, RockstarBypass);

            // NETWORK::_CAN_PLAY_ONLINE bypass
            byte[] CanPlayOnlineBypass = new byte[] { 0x38, 0x60, 0x00, 0x01, 0x4E, 0x80, 0x00, 0x20 };
            PS3.SetMemory(0x003F39CC, CanPlayOnlineBypass);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Join full lobbies into the SCTV slots, without full lobby error. This also makes your name red!", "Lobby Size Bypass", MessageBoxButtons.OK, MessageBoxIcon.Information);
            byte[] BypassLobbyOn = new byte[] { 0x01 }; // true
            PS3.SetMemory(0x1945E4F, BypassLobbyOn);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            byte[] BypassLobbyOff = new byte[] { 0x00 }; // false
            PS3.SetMemory(0x1945E4F, BypassLobbyOff);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            byte[] QATesterModeOn = new byte[] { 0x38, 0x60, 0x00, 0x01 };
            PS3.SetMemory(0x133FCFC, QATesterModeOn);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            byte[] QATesterModeOff = new byte[] { 0x38, 0x60, 0x00, 0x00 };
            PS3.SetMemory(0x133FCFC, QATesterModeOff);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Nobody has ever added script bypass to a rtm tool as a option or even to a sprx as a option only in thread so it happens on game load so yeah anyways it lets you use modded update.rpf with scripts .csc (modloaders) and stuff with other players!", "Script Bypass", MessageBoxButtons.OK, MessageBoxIcon.Information);
            byte[] ScriptBypassOn = new byte[] { 0x60, 0x00, 0x00, 0x00 }; // NOP
            PS3.SetMemory(0x01306254, ScriptBypassOn);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Protections protectionsForm = new Protections();
            protectionsForm.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button18_Click(object sender, EventArgs e)
        {
            byte[] patch = new byte[] { 0x3B, 0xA0, 0x27, 0x72 };
            PS3.SetMemory(0x466F38, patch); // Infinite ammo on
        }

        private void button19_Click(object sender, EventArgs e)
        {
            // Infinite Ammo OFF
            byte[] restore = new byte[] { 0x63, 0xFD, 0x00, 0x00 };
            PS3.SetMemory(0x466F38, restore);
        }
    }
}