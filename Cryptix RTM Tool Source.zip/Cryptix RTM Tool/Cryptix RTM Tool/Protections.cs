﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PS3Lib;

namespace Cryptix_RTM_Tool
{
    public partial class Protections : Form

    {
        public Protections()
        {
            InitializeComponent();
        }
        public static PS3API PS3 = new PS3API();

        private void Protections_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            CryptixRTM cryptixForm = new CryptixRTM();
            cryptixForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            byte[] disableAllEvents = new byte[] { 0x00, 0x00, 0x00, 0x00 };
            PS3.SetMemory(0xA15C24, disableAllEvents);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            byte[] FreezeV3Protection = new byte[] { 0x60, 0x00, 0x00, 0x00 };

            PS3.SetMemory(0x9FBBC8, FreezeV3Protection);
            PS3.SetMemory(0x9FBBCC, FreezeV3Protection);
            PS3.SetMemory(0x9FBA00, FreezeV3Protection);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            byte[] FreezeV3ProtectionOff1 = new byte[] { 0x7E, 0xE1, 0x08, 0x08 }; // 0x9FBBC8
            byte[] FreezeV3ProtectionOff2 = new byte[] { 0x4B, 0xFF, 0xFD, 0xA8 }; // 0x9FBBCC
            byte[] FreezeV3ProtectionOff3 = new byte[] { 0x7E, 0xE1, 0x08, 0x08 }; // 0x9FBA00

            PS3.SetMemory(0x9FBBC8, FreezeV3ProtectionOff1);
            PS3.SetMemory(0x9FBBCC, FreezeV3ProtectionOff2);
            PS3.SetMemory(0x9FBA00, FreezeV3ProtectionOff3);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            byte[] Fakeleaveprotectionv2 = new byte[] { 0x60, 0x00, 0x00, 0x00 }; // NOP

            PS3.SetMemory(0x9FBACC, Fakeleaveprotectionv2);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            byte[] Fakeleaveprotectionv2Off = new byte[] { 0x2C, 0x03, 0x00, 0x00 }; // Original

            PS3.SetMemory(0x9FBACC, Fakeleaveprotectionv2Off);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            byte[] DropKickProtection = new byte[] { 0x60, 0x00, 0x00, 0x00 }; // NOP

            PS3.SetMemory(0x9FFF7C, DropKickProtection);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            byte[] DropKickProtectionOff = new byte[] { 0x4B, 0xFF, 0xF8, 0xA1 }; // Original instruction

            PS3.SetMemory(0x9FFF7C, DropKickProtectionOff);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            byte[] FreezeModelProtection = new byte[] { 0x4E, 0x80, 0x00, 0x20 }; // 'blr' (return - ends function)

            PS3.SetMemory(0x136BF04, FreezeModelProtection);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            byte[] FreezeModelProtectionOff = new byte[] { 0x7C, 0x08, 0x02, 0xA6 }; // Original (mflr r0)

            PS3.SetMemory(0x136BF04, FreezeModelProtectionOff);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            byte[] NonHostKickV1 = new byte[] { 0x60, 0x00, 0x00, 0x00 }; // NOP

            PS3.SetMemory(0x12D1E28, NonHostKickV1);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            byte[] TeleportProtection = new byte[] { 0x4E, 0x80, 0x00, 0x20 }; // blr (return)

            PS3.SetMemory(0x12CB6F8, TeleportProtection);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            byte[] HiddenMode = new byte[] { 0x4E, 0x80, 0x00, 0x20 }; // blr (return)

            PS3.SetMemory(0xA0F8A8, HiddenMode);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            byte[] HiddenModeOff = new byte[] { 0x00, 0x00, 0x00, 0x00 }; // Clear instruction

            PS3.SetMemory(0xA0F8A8, HiddenModeOff);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            byte[] AdminKickProtection = new byte[] { 0x60, 0x00, 0x00, 0x00 };
            PS3.SetMemory(0x1358EE8, AdminKickProtection);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            byte[] AdminKickOff = new byte[] { 0x41, 0x82, 0x02, 0x34 };
            PS3.SetMemory(0x1358EE8, AdminKickOff);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            byte[] BlockExplosionsOn = new byte[] { 0x4E, 0x80, 0x00, 0x20 };
            PS3.SetMemory(0x12C5638, BlockExplosionsOn);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            byte[] BlockExplosionsOff = new byte[] { 0x7C, 0x08, 0x02, 0xA6 };
            PS3.SetMemory(0x12C5638, BlockExplosionsOff); //Blocks People Exploding You (That can also stop laggy shit fps woooow)
        }

        private void button19_Click(object sender, EventArgs e)
        {
            byte[] BlockEntities1 = new byte[] { 0x48, 0x00, 0x00, 0x44 };
            byte[] BlockEntities2 = new byte[] { 0x48, 0x00, 0x00, 0x44 };
            byte[] BlockEntities3 = new byte[] { 0x48, 0x00, 0x00, 0x44 };
            byte[] BlockEntities4 = new byte[] { 0x48, 0x00, 0x00, 0x44 };
            byte[] BlockEntities5 = new byte[] { 0x48, 0x00, 0x00, 0x44 };
            byte[] BlockEntities6 = new byte[] { 0x48, 0x00, 0x00, 0x44 };
            byte[] BlockEntities7 = new byte[] { 0x48, 0x00, 0x00, 0x44 };

            PS3.SetMemory(0x1093228, BlockEntities1);
            PS3.SetMemory(0x133CB14, BlockEntities2);
            PS3.SetMemory(0x133CE0C, BlockEntities3);
            PS3.SetMemory(0x133CAA4, BlockEntities4);
            PS3.SetMemory(0x133CBF0, BlockEntities5);
            PS3.SetMemory(0x133CA34, BlockEntities6);
            PS3.SetMemory(0x133CD34, BlockEntities7);
        }

        private void button20_Click(object sender, EventArgs e)
        {
            byte[] UnblockEntities1 = new byte[] { 0xE5, 0x25, 0xA5, 0x4B };
            byte[] UnblockEntities2 = new byte[] { 0x29, 0x00, 0xD7, 0x8B };
            byte[] UnblockEntities3 = new byte[] { 0x29, 0x00, 0xD7, 0x8B };
            byte[] UnblockEntities4 = new byte[] { 0x29, 0x00, 0xD7, 0x8B };
            byte[] UnblockEntities5 = new byte[] { 0x29, 0x00, 0xD7, 0x8B };
            byte[] UnblockEntities6 = new byte[] { 0x29, 0x00, 0xD7, 0x8B };
            byte[] UnblockEntities7 = new byte[] { 0x29, 0x00, 0xD7, 0x8B };

            PS3.SetMemory(0x1093228, UnblockEntities1);
            PS3.SetMemory(0x133CB14, UnblockEntities2);
            PS3.SetMemory(0x133CE0C, UnblockEntities3);
            PS3.SetMemory(0x133CAA4, UnblockEntities4);
            PS3.SetMemory(0x133CBF0, UnblockEntities5);
            PS3.SetMemory(0x133CA34, UnblockEntities6);
            PS3.SetMemory(0x133CD34, UnblockEntities7);

        }

        private void button21_Click(object sender, EventArgs e)
        {
            byte[] patch = new byte[] { 0x60, 0x00, 0x00, 0x00 };

            PS3.SetMemory(0x009FBBC8, patch);
            PS3.SetMemory(0x009FBBCC, patch);
        }

        private void button22_Click(object sender, EventArgs e)
        {
            byte[] patch = new byte[] { 0x60, 0x00, 0x00, 0x00 };

            PS3.SetMemory(0x12D30D8, patch);
            PS3.SetMemory(0x12D3118, patch);
        }

        private void button23_Click(object sender, EventArgs e)
        {
            byte[] patch = new byte[] { 0x4E, 0x80, 0x00, 0x20 };

            PS3.SetMemory(0x00A0F8A8, patch);
        }

        private void button24_Click(object sender, EventArgs e)
        {
            byte[] patch60000000 = new byte[] { 0x60, 0x00, 0x00, 0x00 };
            byte[] patch4180FF34 = new byte[] { 0x41, 0x80, 0xFF, 0x34 };

            PS3.SetMemory(0x1309E50, patch60000000);
            PS3.SetMemory(0x1309EB4, patch60000000);
            PS3.SetMemory(0x1309EC4, patch4180FF34);
            PS3.SetMemory(0x1309ED4, patch60000000);

        }

        private void button25_Click(object sender, EventArgs e)
        {
            byte[] patch1 = new byte[] { 0x2C, 0x03, 0x00, 0x00 };
            byte[] patch2 = new byte[] { 0x41, 0x81, 0xFF, 0xB8 };
            byte[] patch3 = new byte[] { 0x40, 0x81, 0xFF, 0x34 };

            PS3.SetMemory(0x1309E50, patch1);
            PS3.SetMemory(0x1309EB4, patch2);
            PS3.SetMemory(0x1309EC4, patch3);
        }

        private void button26_Click(object sender, EventArgs e)
        {
            byte[] patch60000000 = new byte[] { 0x60, 0x00, 0x00, 0x00 };

            PS3.SetMemory(0x12D3088, patch60000000); // on
            PS3.SetMemory(0x12D303C, patch60000000);
        }

        private void button27_Click(object sender, EventArgs e)
        {
            byte[] patch1 = new byte[] { 0x4B, 0xCD, 0xE0, 0x89 };
            byte[] patch2 = new byte[] { 0x4B, 0x72, 0x5B, 0xFD };

            PS3.SetMemory(0x12D3088, patch1);
            PS3.SetMemory(0x12D303C, patch2);
        }
    }
}
